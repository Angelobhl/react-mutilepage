import HttpRequest from '../../../utils/axios'
export * from '../../../utils/axios'
export default new HttpRequest()
