const Api = {
    api: {
        devApiBaseUrl: '//sports-beta.zhanqi.com',
        proApiBaseUrl: '',
    },
};

export default Api
